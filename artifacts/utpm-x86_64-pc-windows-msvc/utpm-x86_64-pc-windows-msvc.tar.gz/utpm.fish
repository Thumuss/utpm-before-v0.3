# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_utpm_global_optspecs
	string join \n v/verbose= o/output-format= D/dry-run h/help V/version
end

function __fish_utpm_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_utpm_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_utpm_using_subcommand
	set -l cmd (__fish_utpm_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c utpm -n "__fish_utpm_needs_command" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_needs_command" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_needs_command" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_needs_command" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_needs_command" -s V -l version -d 'Print version'
complete -c utpm -n "__fish_utpm_needs_command" -f -a "project" -d 'Subcommands for managing the current project'
complete -c utpm -n "__fish_utpm_needs_command" -f -a "prj" -d 'Subcommands for managing the current project'
complete -c utpm -n "__fish_utpm_needs_command" -f -a "packages" -d 'Subcommands for managing local packages'
complete -c utpm -n "__fish_utpm_needs_command" -f -a "pkg" -d 'Subcommands for managing local packages'
complete -c utpm -n "__fish_utpm_needs_command" -f -a "generate" -d 'Generate shell completion scripts'
complete -c utpm -n "__fish_utpm_needs_command" -f -a "g" -d 'Generate shell completion scripts'
complete -c utpm -n "__fish_utpm_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "link" -d 'Link the current project to the local package directory'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "l" -d 'Link the current project to the local package directory'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "init" -d 'Create a new `typst.toml` manifest for a project'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "n" -d 'Create a new `typst.toml` manifest for a project'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "publish" -d 'Publish your package to the Typst Universe'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "p" -d 'Publish your package to the Typst Universe'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "clone" -d 'Clone a package from the Typst Universe or a local directory'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "c" -d 'Clone a package from the Typst Universe or a local directory'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "bump" -d 'Bump the version of your package in `typst.toml` and other project files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "b" -d 'Bump the version of your package in `typst.toml` and other project files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "sync" -d 'Synchronise all your dependencies into their last version'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "s" -d 'Synchronise all your dependencies into their last version'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "metadata" -d 'Get metadata from typst.toml for use in scripts'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "m" -d 'Get metadata from typst.toml for use in scripts'
complete -c utpm -n "__fish_utpm_using_subcommand project; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s f -l force -d 'Force the copy of the directory or creation of the symlink'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s n -l no-copy -d 'Create a symlink instead of copying the project files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s i -d 'Use .ignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s g -d 'Use .gitignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s t -d 'Use .typstignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s G -d 'Use global .gitignore to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s x -d 'Use .git/info/exclude files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from link" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s f -l force -d 'Force the copy of the directory or creation of the symlink'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s n -l no-copy -d 'Create a symlink instead of copying the project files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s i -d 'Use .ignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s g -d 'Use .gitignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s t -d 'Use .typstignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s G -d 'Use global .gitignore to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s x -d 'Use .git/info/exclude files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from l" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s n -l name -d 'Name of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s V -l version -d 'Version of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s e -l entrypoint -d 'Path to the main file of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s a -l authors -d 'Authors of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s l -l license -d 'License of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s d -l description -d 'A short description of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s r -l repository -d 'The link to your repository' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s H -l homepage -d 'Link to your homepage' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s k -l keywords -d 'Keywords to find your project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s c -l compiler -d 'Minimum compiler version required' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s x -l exclude -d 'Files to exclude from the package' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s N -l namespace -d 'Namespace to put your package in' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s C -l categories -d 'Categories to add to your typst.toml' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -l disciplines -d 'Disciplines to add to your typst.toml' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -l template-path -d 'Path to a template file to use' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -l template-entrypoint -d 'Entrypoint for the template' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -l template-thumbnail -d 'Thumbnail for the template' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s m -l cli -d 'Disable interactive session and use command-line arguments only'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s f -l force -d 'Force the creation of the manifest file, overwriting if it exists'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s p -l populate -d 'Populate the project with example files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from init" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s n -l name -d 'Name of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s V -l version -d 'Version of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s e -l entrypoint -d 'Path to the main file of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s a -l authors -d 'Authors of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s l -l license -d 'License of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s d -l description -d 'A short description of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s r -l repository -d 'The link to your repository' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s H -l homepage -d 'Link to your homepage' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s k -l keywords -d 'Keywords to find your project' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s c -l compiler -d 'Minimum compiler version required' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s x -l exclude -d 'Files to exclude from the package' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s N -l namespace -d 'Namespace to put your package in' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s C -l categories -d 'Categories to add to your typst.toml' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -l disciplines -d 'Disciplines to add to your typst.toml' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -l template-path -d 'Path to a template file to use' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -l template-entrypoint -d 'Entrypoint for the template' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -l template-thumbnail -d 'Thumbnail for the template' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s m -l cli -d 'Disable interactive session and use command-line arguments only'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s f -l force -d 'Force the creation of the manifest file, overwriting if it exists'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s p -l populate -d 'Populate the project with example files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from n" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s c -d 'Path to a custom ignore file' -r -F
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s m -d 'Specify a message for the new commit' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s i -d 'Use .ignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s g -d 'Use .gitignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s t -d 'Use .typstignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s G -d 'Use global .gitignore to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s x -d 'Use .git/info/exclude files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -l bypass-warning -d 'Bypass the warning prompts'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s p -d 'Prepare the package for publishing without creating a pull request'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from publish" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s c -d 'Path to a custom ignore file' -r -F
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s m -d 'Specify a message for the new commit' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s i -d 'Use .ignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s g -d 'Use .gitignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s t -d 'Use .typstignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s G -d 'Use global .gitignore to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s x -d 'Use .git/info/exclude files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -l bypass-warning -d 'Bypass the warning prompts'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s p -d 'Prepare the package for publishing without creating a pull request'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from p" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from clone" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from clone" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from clone" -s d -d 'Download the package to the cache without copying it to the target directory'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from clone" -s f -d 'Force cloning even if the destination path is not empty'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from clone" -s r -d 'Force re-downloading the package even if it exists in the cache'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from clone" -s s -d 'Create a symlink to the cloned package instead of copying'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from clone" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from clone" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from c" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from c" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from c" -s d -d 'Download the package to the cache without copying it to the target directory'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from c" -s f -d 'Force cloning even if the destination path is not empty'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from c" -s r -d 'Force re-downloading the package even if it exists in the cache'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from c" -s s -d 'Create a symlink to the cloned package instead of copying'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from c" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from c" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from bump" -s t -l tag -d 'The tag to look at when you bump other files. If the file is written in markdown or html, it will looks into the code to find `<tag>0.1.0</tag>`' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from bump" -s i -l include -d 'Files to include in the list. (typst.toml is already included)' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from bump" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from bump" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from bump" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from bump" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from b" -s t -l tag -d 'The tag to look at when you bump other files. If the file is written in markdown or html, it will looks into the code to find `<tag>0.1.0</tag>`' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from b" -s i -l include -d 'Files to include in the list. (typst.toml is already included)' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from b" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from b" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from b" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from b" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from sync" -s f -l files -d 'Files to sync packages. Default to all files' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from sync" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from sync" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from sync" -s c -l check-only -d 'Only check if they are new versions and write them on the file itself'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from sync" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from sync" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from s" -s f -l files -d 'Files to sync packages. Default to all files' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from s" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from s" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from s" -s c -l check-only -d 'Only check if they are new versions and write them on the file itself'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from s" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from s" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from metadata" -s p -l path -d 'Path to the project directory. Defaults to the current directory' -r -F
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from metadata" -s f -l field -d 'Specific field to extract (e.g., name, version, authors). If not specified, all metadata will be displayed' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from metadata" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from metadata" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from metadata" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from metadata" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from m" -s p -l path -d 'Path to the project directory. Defaults to the current directory' -r -F
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from m" -s f -l field -d 'Specific field to extract (e.g., name, version, authors). If not specified, all metadata will be displayed' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from m" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from m" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from m" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from m" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from help" -f -a "link" -d 'Link the current project to the local package directory'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from help" -f -a "init" -d 'Create a new `typst.toml` manifest for a project'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from help" -f -a "publish" -d 'Publish your package to the Typst Universe'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from help" -f -a "clone" -d 'Clone a package from the Typst Universe or a local directory'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from help" -f -a "bump" -d 'Bump the version of your package in `typst.toml` and other project files'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from help" -f -a "sync" -d 'Synchronise all your dependencies into their last version'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from help" -f -a "metadata" -d 'Get metadata from typst.toml for use in scripts'
complete -c utpm -n "__fish_utpm_using_subcommand project; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "link" -d 'Link the current project to the local package directory'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "l" -d 'Link the current project to the local package directory'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "init" -d 'Create a new `typst.toml` manifest for a project'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "n" -d 'Create a new `typst.toml` manifest for a project'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "publish" -d 'Publish your package to the Typst Universe'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "p" -d 'Publish your package to the Typst Universe'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "clone" -d 'Clone a package from the Typst Universe or a local directory'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "c" -d 'Clone a package from the Typst Universe or a local directory'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "bump" -d 'Bump the version of your package in `typst.toml` and other project files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "b" -d 'Bump the version of your package in `typst.toml` and other project files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "sync" -d 'Synchronise all your dependencies into their last version'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "s" -d 'Synchronise all your dependencies into their last version'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "metadata" -d 'Get metadata from typst.toml for use in scripts'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "m" -d 'Get metadata from typst.toml for use in scripts'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and not __fish_seen_subcommand_from link l init n publish p clone c bump b sync s metadata m help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s f -l force -d 'Force the copy of the directory or creation of the symlink'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s n -l no-copy -d 'Create a symlink instead of copying the project files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s i -d 'Use .ignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s g -d 'Use .gitignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s t -d 'Use .typstignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s G -d 'Use global .gitignore to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s x -d 'Use .git/info/exclude files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from link" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s f -l force -d 'Force the copy of the directory or creation of the symlink'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s n -l no-copy -d 'Create a symlink instead of copying the project files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s i -d 'Use .ignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s g -d 'Use .gitignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s t -d 'Use .typstignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s G -d 'Use global .gitignore to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s x -d 'Use .git/info/exclude files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from l" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s n -l name -d 'Name of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s V -l version -d 'Version of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s e -l entrypoint -d 'Path to the main file of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s a -l authors -d 'Authors of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s l -l license -d 'License of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s d -l description -d 'A short description of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s r -l repository -d 'The link to your repository' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s H -l homepage -d 'Link to your homepage' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s k -l keywords -d 'Keywords to find your project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s c -l compiler -d 'Minimum compiler version required' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s x -l exclude -d 'Files to exclude from the package' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s N -l namespace -d 'Namespace to put your package in' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s C -l categories -d 'Categories to add to your typst.toml' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -l disciplines -d 'Disciplines to add to your typst.toml' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -l template-path -d 'Path to a template file to use' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -l template-entrypoint -d 'Entrypoint for the template' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -l template-thumbnail -d 'Thumbnail for the template' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s m -l cli -d 'Disable interactive session and use command-line arguments only'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s f -l force -d 'Force the creation of the manifest file, overwriting if it exists'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s p -l populate -d 'Populate the project with example files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from init" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s n -l name -d 'Name of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s V -l version -d 'Version of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s e -l entrypoint -d 'Path to the main file of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s a -l authors -d 'Authors of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s l -l license -d 'License of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s d -l description -d 'A short description of the project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s r -l repository -d 'The link to your repository' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s H -l homepage -d 'Link to your homepage' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s k -l keywords -d 'Keywords to find your project' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s c -l compiler -d 'Minimum compiler version required' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s x -l exclude -d 'Files to exclude from the package' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s N -l namespace -d 'Namespace to put your package in' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s C -l categories -d 'Categories to add to your typst.toml' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -l disciplines -d 'Disciplines to add to your typst.toml' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -l template-path -d 'Path to a template file to use' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -l template-entrypoint -d 'Entrypoint for the template' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -l template-thumbnail -d 'Thumbnail for the template' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s m -l cli -d 'Disable interactive session and use command-line arguments only'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s f -l force -d 'Force the creation of the manifest file, overwriting if it exists'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s p -l populate -d 'Populate the project with example files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from n" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s c -d 'Path to a custom ignore file' -r -F
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s m -d 'Specify a message for the new commit' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s i -d 'Use .ignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s g -d 'Use .gitignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s t -d 'Use .typstignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s G -d 'Use global .gitignore to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s x -d 'Use .git/info/exclude files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -l bypass-warning -d 'Bypass the warning prompts'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s p -d 'Prepare the package for publishing without creating a pull request'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from publish" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s c -d 'Path to a custom ignore file' -r -F
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s m -d 'Specify a message for the new commit' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s i -d 'Use .ignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s g -d 'Use .gitignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s t -d 'Use .typstignore files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s G -d 'Use global .gitignore to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s x -d 'Use .git/info/exclude files to filter packaged files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -l bypass-warning -d 'Bypass the warning prompts'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s p -d 'Prepare the package for publishing without creating a pull request'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from p" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from clone" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from clone" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from clone" -s d -d 'Download the package to the cache without copying it to the target directory'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from clone" -s f -d 'Force cloning even if the destination path is not empty'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from clone" -s r -d 'Force re-downloading the package even if it exists in the cache'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from clone" -s s -d 'Create a symlink to the cloned package instead of copying'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from clone" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from clone" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from c" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from c" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from c" -s d -d 'Download the package to the cache without copying it to the target directory'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from c" -s f -d 'Force cloning even if the destination path is not empty'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from c" -s r -d 'Force re-downloading the package even if it exists in the cache'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from c" -s s -d 'Create a symlink to the cloned package instead of copying'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from c" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from c" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from bump" -s t -l tag -d 'The tag to look at when you bump other files. If the file is written in markdown or html, it will looks into the code to find `<tag>0.1.0</tag>`' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from bump" -s i -l include -d 'Files to include in the list. (typst.toml is already included)' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from bump" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from bump" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from bump" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from bump" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from b" -s t -l tag -d 'The tag to look at when you bump other files. If the file is written in markdown or html, it will looks into the code to find `<tag>0.1.0</tag>`' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from b" -s i -l include -d 'Files to include in the list. (typst.toml is already included)' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from b" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from b" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from b" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from b" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from sync" -s f -l files -d 'Files to sync packages. Default to all files' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from sync" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from sync" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from sync" -s c -l check-only -d 'Only check if they are new versions and write them on the file itself'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from sync" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from sync" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from s" -s f -l files -d 'Files to sync packages. Default to all files' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from s" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from s" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from s" -s c -l check-only -d 'Only check if they are new versions and write them on the file itself'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from s" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from s" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from metadata" -s p -l path -d 'Path to the project directory. Defaults to the current directory' -r -F
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from metadata" -s f -l field -d 'Specific field to extract (e.g., name, version, authors). If not specified, all metadata will be displayed' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from metadata" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from metadata" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from metadata" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from metadata" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from m" -s p -l path -d 'Path to the project directory. Defaults to the current directory' -r -F
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from m" -s f -l field -d 'Specific field to extract (e.g., name, version, authors). If not specified, all metadata will be displayed' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from m" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from m" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from m" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from m" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from help" -f -a "link" -d 'Link the current project to the local package directory'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from help" -f -a "init" -d 'Create a new `typst.toml` manifest for a project'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from help" -f -a "publish" -d 'Publish your package to the Typst Universe'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from help" -f -a "clone" -d 'Clone a package from the Typst Universe or a local directory'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from help" -f -a "bump" -d 'Bump the version of your package in `typst.toml` and other project files'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from help" -f -a "sync" -d 'Synchronise all your dependencies into their last version'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from help" -f -a "metadata" -d 'Get metadata from typst.toml for use in scripts'
complete -c utpm -n "__fish_utpm_using_subcommand prj; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "list" -d 'List all packages in your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "l" -d 'List all packages in your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "path" -d 'Display the path to the typst packages folder'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "p" -d 'Display the path to the typst packages folder'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "unlink" -d 'Delete a package from your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "u" -d 'Delete a package from your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "get" -d 'Get specific/all packages from the remote'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "g" -d 'Get specific/all packages from the remote'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "install" -d 'Install a package from a git repository into a namespace'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "i" -d 'Install a package from a git repository into a namespace'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from list" -s i -l include -d 'Specify subdirectories to include in the list' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from list" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from list" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from list" -s a -l all -d 'List all packages, including those in the `@preview` namespace'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from list" -s t -l tree -d 'Display the packages as a tree. Only works with text output'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from list" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from l" -s i -l include -d 'Specify subdirectories to include in the list' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from l" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from l" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from l" -s a -l all -d 'List all packages, including those in the `@preview` namespace'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from l" -s t -l tree -d 'Display the packages as a tree. Only works with text output'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from l" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from l" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from path" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from path" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from path" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from path" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from p" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from p" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from p" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from p" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from unlink" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from unlink" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from unlink" -s y -l yes -d 'Confirm the deletion of the package directory without a prompt'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from unlink" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from unlink" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from u" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from u" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from u" -s y -l yes -d 'Confirm the deletion of the package directory without a prompt'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from u" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from u" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from get" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from get" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from get" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from get" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from g" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from g" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from g" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from g" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from install" -s n -l namespace -d 'The namespace you want to put your installed package. Default to local' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from install" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from install" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from install" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from install" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from i" -s n -l namespace -d 'The namespace you want to put your installed package. Default to local' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from i" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from i" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from i" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from i" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from help" -f -a "list" -d 'List all packages in your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from help" -f -a "path" -d 'Display the path to the typst packages folder'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from help" -f -a "unlink" -d 'Delete a package from your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from help" -f -a "get" -d 'Get specific/all packages from the remote'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from help" -f -a "install" -d 'Install a package from a git repository into a namespace'
complete -c utpm -n "__fish_utpm_using_subcommand packages; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "list" -d 'List all packages in your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "l" -d 'List all packages in your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "path" -d 'Display the path to the typst packages folder'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "p" -d 'Display the path to the typst packages folder'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "unlink" -d 'Delete a package from your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "u" -d 'Delete a package from your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "get" -d 'Get specific/all packages from the remote'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "g" -d 'Get specific/all packages from the remote'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "install" -d 'Install a package from a git repository into a namespace'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "i" -d 'Install a package from a git repository into a namespace'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and not __fish_seen_subcommand_from list l path p unlink u get g install i help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from list" -s i -l include -d 'Specify subdirectories to include in the list' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from list" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from list" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from list" -s a -l all -d 'List all packages, including those in the `@preview` namespace'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from list" -s t -l tree -d 'Display the packages as a tree. Only works with text output'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from list" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from l" -s i -l include -d 'Specify subdirectories to include in the list' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from l" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from l" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from l" -s a -l all -d 'List all packages, including those in the `@preview` namespace'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from l" -s t -l tree -d 'Display the packages as a tree. Only works with text output'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from l" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from l" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from path" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from path" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from path" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from path" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from p" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from p" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from p" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from p" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from unlink" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from unlink" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from unlink" -s y -l yes -d 'Confirm the deletion of the package directory without a prompt'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from unlink" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from unlink" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from u" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from u" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from u" -s y -l yes -d 'Confirm the deletion of the package directory without a prompt'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from u" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from u" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from get" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from get" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from get" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from get" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from g" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from g" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from g" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from g" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from install" -s n -l namespace -d 'The namespace you want to put your installed package. Default to local' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from install" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from install" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from install" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from install" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from i" -s n -l namespace -d 'The namespace you want to put your installed package. Default to local' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from i" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from i" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from i" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from i" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "list" -d 'List all packages in your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "path" -d 'Display the path to the typst packages folder'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "unlink" -d 'Delete a package from your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "get" -d 'Get specific/all packages from the remote'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "install" -d 'Install a package from a git repository into a namespace'
complete -c utpm -n "__fish_utpm_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c utpm -n "__fish_utpm_using_subcommand generate" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand generate" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand generate" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand generate" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand g" -s v -l verbose -d 'Enable verbose logging for debugging purposes' -r
complete -c utpm -n "__fish_utpm_using_subcommand g" -s o -l output-format -d 'The output format for command results' -r -f -a "json\t'JSON format'
toml\t'TOML format'
text\t'Plain text format'"
complete -c utpm -n "__fish_utpm_using_subcommand g" -s D -l dry-run -d 'Preview changes without writing to disk (dry-run mode)'
complete -c utpm -n "__fish_utpm_using_subcommand g" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c utpm -n "__fish_utpm_using_subcommand help; and not __fish_seen_subcommand_from project packages generate help" -f -a "project" -d 'Subcommands for managing the current project'
complete -c utpm -n "__fish_utpm_using_subcommand help; and not __fish_seen_subcommand_from project packages generate help" -f -a "packages" -d 'Subcommands for managing local packages'
complete -c utpm -n "__fish_utpm_using_subcommand help; and not __fish_seen_subcommand_from project packages generate help" -f -a "generate" -d 'Generate shell completion scripts'
complete -c utpm -n "__fish_utpm_using_subcommand help; and not __fish_seen_subcommand_from project packages generate help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from project" -f -a "link" -d 'Link the current project to the local package directory'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from project" -f -a "init" -d 'Create a new `typst.toml` manifest for a project'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from project" -f -a "publish" -d 'Publish your package to the Typst Universe'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from project" -f -a "clone" -d 'Clone a package from the Typst Universe or a local directory'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from project" -f -a "bump" -d 'Bump the version of your package in `typst.toml` and other project files'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from project" -f -a "sync" -d 'Synchronise all your dependencies into their last version'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from project" -f -a "metadata" -d 'Get metadata from typst.toml for use in scripts'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from packages" -f -a "list" -d 'List all packages in your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from packages" -f -a "path" -d 'Display the path to the typst packages folder'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from packages" -f -a "unlink" -d 'Delete a package from your local storage'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from packages" -f -a "get" -d 'Get specific/all packages from the remote'
complete -c utpm -n "__fish_utpm_using_subcommand help; and __fish_seen_subcommand_from packages" -f -a "install" -d 'Install a package from a git repository into a namespace'
